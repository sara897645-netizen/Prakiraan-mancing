import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const Color _navy = Color(0xFF0A2E45);
const Color _water = Color(0xFFE6F0F2);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: _navy,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: _water,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));
  runApp(const PrakiraanMancingApp());
}

class PrakiraanMancingApp extends StatelessWidget {
  const PrakiraanMancingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Prakiraan Mancing',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: _navy),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  late final WebViewController _controller;
  bool _loading = true;
  // Aktif setelah pengguna membuka Google Maps dari aplikasi; saat kembali, tautan yang disalin dibaca sekali.
  bool _awaitClip = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(_water)
      // Tautan di halaman (Google Maps, BMKG, pasanglaut.com) dibuka di browser HP.
      ..addJavaScriptChannel('AppOpen',
          onMessageReceived: (JavaScriptMessage m) => _open(m.message))
      // Tombol "Pakai lokasi saya" memakai GPS bawaan HP.
      ..addJavaScriptChannel('AppGeo',
          onMessageReceived: (JavaScriptMessage m) => _locate())
      // Memilih lokasi: buka Google Maps, lalu baca tautan yang disalin saat kembali.
      ..addJavaScriptChannel('AppMaps', onMessageReceived: (JavaScriptMessage m) {
        _awaitClip = true;
        _open(m.message);
      })
      ..addJavaScriptChannel('AppPaste',
          onMessageReceived: (JavaScriptMessage m) => _sendClipboard('__pmPaste'))
      ..addJavaScriptChannel('AppResolve',
          onMessageReceived: (JavaScriptMessage m) => _resolve(m.message))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (String url) {
          if (mounted) setState(() => _loading = false);
        },
        onNavigationRequest: (NavigationRequest request) {
          final String u = request.url;
          if (u.startsWith('file:') ||
              u.startsWith('about:') ||
              u.startsWith('data:')) {
            return NavigationDecision.navigate;
          }
          _open(u);
          return NavigationDecision.prevent;
        },
      ))
      ..loadFlutterAsset('assets/index.html');
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _awaitClip) {
      _awaitClip = false;
      // Jeda singkat: Android baru mengizinkan baca clipboard setelah aplikasi benar-benar aktif.
      Future<void>.delayed(
          const Duration(milliseconds: 500), () => _sendClipboard('__pmClip'));
    }
  }

  Future<void> _sendClipboard(String fn) async {
    String text = '';
    try {
      final ClipboardData? data = await Clipboard.getData(Clipboard.kTextPlain);
      text = data?.text ?? '';
    } catch (_) {}
    if (!mounted) return;
    await _controller
        .runJavaScript('window.${fn}&&window.${fn}(${jsonEncode(text)})');
  }

  // Tautan pendek (maps.app.goo.gl) diikuti sampai alamat akhir yang memuat koordinat.
  Future<void> _resolve(String url) async {
    String out = '';
    try {
      out = await _expand(url);
    } catch (_) {}
    if (!mounted) return;
    await _controller.runJavaScript(
        'window.__pmResolved&&window.__pmResolved(${jsonEncode(out)})');
  }

  Future<String> _expand(String url) async {
    final HttpClient client = HttpClient();
    client.connectionTimeout = const Duration(seconds: 10);
    client.userAgent =
        'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';
    try {
      Uri uri = Uri.parse(url);
      for (int i = 0; i < 6; i++) {
        final HttpClientRequest req = await client.getUrl(uri);
        req.followRedirects = false;
        final HttpClientResponse res =
            await req.close().timeout(const Duration(seconds: 12));
        final String? loc = res.headers.value(HttpHeaders.locationHeader);
        if (res.statusCode >= 300 && res.statusCode < 400 && loc != null) {
          await res.drain<void>();
          uri = uri.resolve(loc);
          continue;
        }
        String body = '';
        try {
          body = await res
              .transform(utf8.decoder)
              .join()
              .timeout(const Duration(seconds: 12));
        } catch (_) {}
        if (body.length > 100000) body = body.substring(0, 100000);
        return '${uri.toString()}\n$body';
      }
      return uri.toString();
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _open(String url) async {
    final Uri? uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  Future<void> _locate() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw Exception('gps-off');
      }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        throw Exception('denied');
      }
      final Position pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      ).timeout(const Duration(seconds: 20));
      await _controller.runJavaScript(
          'window.__pmGeo&&window.__pmGeo(${pos.latitude},${pos.longitude})');
    } catch (_) {
      await _controller.runJavaScript('window.__pmGeoErr&&window.__pmGeoErr()');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _water,
      body: Column(
        children: <Widget>[
          Container(
            color: _navy,
            height: MediaQuery.paddingOf(context).top,
          ),
          Expanded(
            child: SafeArea(
              top: false,
              child: Stack(
                children: <Widget>[
                  WebViewWidget(controller: _controller),
                  if (_loading) const Center(child: CircularProgressIndicator()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
