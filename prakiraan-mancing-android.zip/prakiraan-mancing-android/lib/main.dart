import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const Color _navy = Color(0xFF0A2E45);
const Color _water = Color(0xFFE6F0F2);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: _navy,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: _water,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));
  runApp(const PrakiraanMancingApp());
}

class PrakiraanMancingApp extends StatelessWidget {
  const PrakiraanMancingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Prakiraan Mancing',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: _navy),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final WebViewController _controller;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(_water)
      // Tautan di halaman (Google Maps, BMKG, pasanglaut.com) dibuka di browser HP.
      ..addJavaScriptChannel('AppOpen',
          onMessageReceived: (JavaScriptMessage m) => _open(m.message))
      // Tombol "Pakai lokasi saya" memakai GPS bawaan HP.
      ..addJavaScriptChannel('AppGeo',
          onMessageReceived: (JavaScriptMessage m) => _locate())
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (String url) {
          if (mounted) setState(() => _loading = false);
        },
        onNavigationRequest: (NavigationRequest request) {
          final String u = request.url;
          if (u.startsWith('file:') ||
              u.startsWith('about:') ||
              u.startsWith('data:')) {
            return NavigationDecision.navigate;
          }
          _open(u);
          return NavigationDecision.prevent;
        },
      ))
      ..loadFlutterAsset('assets/index.html');
  }

  Future<void> _open(String url) async {
    final Uri? uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  Future<void> _locate() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw Exception('gps-off');
      }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        throw Exception('denied');
      }
      final Position pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      ).timeout(const Duration(seconds: 20));
      await _controller.runJavaScript(
          'window.__pmGeo&&window.__pmGeo(${pos.latitude},${pos.longitude})');
    } catch (_) {
      await _controller.runJavaScript('window.__pmGeoErr&&window.__pmGeoErr()');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _water,
      body: Column(
        children: <Widget>[
          Container(
            color: _navy,
            height: MediaQuery.paddingOf(context).top,
          ),
          Expanded(
            child: SafeArea(
              top: false,
              child: Stack(
                children: <Widget>[
                  WebViewWidget(controller: _controller),
                  if (_loading) const Center(child: CircularProgressIndicator()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
