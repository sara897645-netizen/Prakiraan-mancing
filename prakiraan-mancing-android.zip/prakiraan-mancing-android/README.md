# Prakiraan Mancing (Android)

Aplikasi Android yang membungkus halaman `assets/index.html` (prakiraan waktu mancing dari pasang surut, angin, gelombang, dan bulan) dengan Flutter WebView. Data diambil dari Open-Meteo saat HP tersambung internet.

## Membuat APK

1. Buat repo baru di GitHub (boleh privat), lalu unggah seluruh isi folder ini. Pastikan folder `.github` dan `ci` ikut terunggah.
2. Buka tab **Actions**. Workflow **Build APK** jalan otomatis setiap ada push, atau tekan **Run workflow**. Butuh sekitar 5 sampai 10 menit.
3. Unduh APK dari salah satu tempat ini:
   - **Releases** di halaman utama repo, file `PrakiraanMancing.apk` (paling mudah dari HP).
   - **Actions**, pilih run terakhir, bagian **Artifacts**, `PrakiraanMancing-apk` (berupa zip).
4. Di HP, buka file APK dan izinkan pemasangan dari sumber tidak dikenal bila diminta. Play Protect bisa memberi peringatan karena aplikasi ini tidak dari Play Store.

## Memperbarui

Ganti `assets/index.html` dengan versi baru, lalu push. APK baru bisa dipasang menimpa yang lama dan data di dalam aplikasi tetap ada, karena setiap build memakai kunci yang sama (`ci/debug.keystore`).

## Memilih lokasi

Pilih "Lokasi sendiri…" di aplikasi, lalu: cari nama tempat, atau tekan **Buka Google Maps**, ketuk Bagikan dan Salin di sana, lalu kembali ke aplikasi (tautan terbaca otomatis, atau ketuk **Tempel tautan**). Tautan pendek `maps.app.goo.gl` diikuti oleh aplikasi sampai koordinatnya ketemu.

## Catatan

- `ci/debug.keystore` adalah kunci debug standar Android (kata sandi `android`). Cukup untuk dipasang langsung di HP, tidak untuk Play Store. Untuk Play Store, buat kunci rilis sendiri.
- Aplikasi meminta izin internet dan lokasi (hanya untuk tombol "Pakai lokasi saya").
- Data prakiraan dari [Open-Meteo](https://open-meteo.com) (CC BY 4.0). Gratis untuk penggunaan non-komersial.
